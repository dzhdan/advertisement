<?php
return array(
	'oranges' => 'апельсины',
	'{brand} bags' => 'сумочки {brand}',
	'in the cart: {n}' => 'в корзине: {n}',
	'cucumber|cucumbers' => 'огурец|огурца|огурцов|огурца',
	'{n} cucumber|{n} cucumbers' => '{n} огурец|{n} огурца|{n} огурцов',
	'{sign} {n} cucumber|{sign} {n} cucumbers' => '{sign} {n} огурец|{sign} {n} огурца|{sign} {n} огурцов',
	'zombie|zombies' => 'зомби',
	'hat|hats' => 'шляпа|шляпы|шляп|useless1|useless2',
	'news' => 'новость|новости|новостей',
	'syn1|syn2|syn3' => 'син1|син2',
	'n==1#one book|n>1#many books' => 'n==1#одна книга|n>1#много книг',
	'1#one book|n>1#many books' => '1#одна книга|n>1#много книг',
);