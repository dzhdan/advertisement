<?php
return array(
	'kiss|kisses' => 'k-s',
);