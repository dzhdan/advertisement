<?php
return array(
	'cucumber|cucumbers' => 'cucumber|cucumbers',
);