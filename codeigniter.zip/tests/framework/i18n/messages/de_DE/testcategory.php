<?php

return array(
	'Hello World!' => 'Hallo Welt!',
);