<?php

return array(
	'param1'=>'value1',
	'param2'=>false,
	'param3'=>123,
	"backquote"=>"\\back'quote'",
/*	'object'=>array(
		'param1'=>null,
		'param2'=>'123',
		'param3'=>array(
			'param1'=>'kkk',
			'ddd',
			'',
		),
	),*/
);