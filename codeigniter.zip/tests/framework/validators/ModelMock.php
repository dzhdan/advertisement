<?php

class ModelMock extends CFormModel
{
    public $foo;
    
    public $bar;
}