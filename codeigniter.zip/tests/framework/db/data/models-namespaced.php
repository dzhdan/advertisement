<?php
namespace yiiArExample\testspace;
use \CActiveRecord;

class Example extends CActiveRecord
{
}
