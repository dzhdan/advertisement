INSERT INTO `category` VALUES (1, 'buy', 'Продам', 0);
INSERT INTO `category` VALUES (2, 'sale', 'Куплю', 0);
INSERT INTO `category` VALUES (3, 'services', 'Услуги', 0);
INSERT INTO `category` VALUES (4, 'job', 'Работа', 0);
INSERT INTO `category` VALUES (5, 'rent', 'Аренда', 0);
INSERT INTO `category` VALUES (7, 'other', 'Разное', 0);
INSERT INTO `category` VALUES (8, 'DX', 'RFC', 0);
