<?php
/* @var $this SiteController */
/* @var $model LoginForm */
/* @var $form CActiveForm  */

$this->pageTitle = 'Registration Form';
?>
<p>Регистрация прошла успешно.</p>
<p> Для завершения регистрации пройдите по ссылке высланной вам на email.</p>
